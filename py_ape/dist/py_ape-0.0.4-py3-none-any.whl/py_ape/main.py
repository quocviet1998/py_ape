from .ape_func import *

def show_authors():
 print("Authors: VietPQ - ToiNV | A package based on BigGorilla package")